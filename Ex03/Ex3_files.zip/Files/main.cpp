#include <QApplication>
#include "widget.h"

/* Steps

***  Qt & Cmake ***
1) Add QWidget .cpp/.h/.ui file
2) Add files to Cmake
3) find packages and link, here Qt::Widgets
4) Start widget in main

***  QCustomplot ***
1) Add sources to folder structure and cmake (source/path/QPrintsupport) -> Ready
2) Add customplot to widget (promote widget to QCustomPlot)
3)
*/

int main( int argc , char * argv [])
{
    QApplication a(argc, argv);

    Widget w;
    w.show();

    return a.exec();
}
